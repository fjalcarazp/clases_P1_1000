/*
1 - Crea una funcion que se llame "clear(elem)" a la cual le puedas pasar un elemento y elimine todo lo que haya en su interior.

2 - Crea una lista preguntando al usuario con un prompt los elementos de la lista, cuando el usuario le de a cancelar entonces dejamos de preguntarle, y pintamos la lista en el HTML.

3 - Crea un reloj que vaya cambiando en tiempo real, y que las horas se vean de color rojo, los minutos de color verde y los segundos de color azul.
*/

